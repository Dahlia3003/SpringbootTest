package org.example.wygotest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WygotestApplication {

    public static void main(String[] args) {
        SpringApplication.run(WygotestApplication.class, args);
    }

}
